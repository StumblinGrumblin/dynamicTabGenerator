$(function() {
	$('.tabs li a').click(function(){
		$('.content').hide();
		$('.tabs li.active').removeClass('active');
		$(this).parent().addClass('active');
		$($(this).attr('href')).fadeIn(300);
	});
	$('.tabs li:nth-child(2) a').click();
});