//ELEMENT GENERATOR ON FORM SUBMIT
function createTabBox(numTabs, defaultTab) {
	$("#main").append("<div class='subMain'><div class='nav'><ul class='tabs clearfix'></ul></div><div class='container'></div></div>")
	
	for (var i=1; i <= numTabs; i++){
		$('.subMain:last ul.tabs').append("<li><a href='#'>Tab " + i + "</a></li>");
		$('.subMain:last div.container').append("<div class='content'><h2>Content for Tab " + i + "</h2>" + loremIpsum[i] + "</div>")
	};

	if (defaultTab > 0 && defaultTab <= numTabs) {
		$('.subMain:last .tabs li:eq(' + (defaultTab - 1) + ')').click();	
	} else {
		$('.subMain:last .tabs li:eq(0)').click();
	}
};

//Set active elements to in last TabBox to randomly selected color
function randomColor() {
	var randomNumber = Math.floor(Math.random() * 3);
	var colors = ['red', 'blue', 'green'];
	var activeTab = '.subMain:last li.active';
	var container = '.subMain:last .container';

	$(activeTab).addClass(colors[randomNumber]);
	$(container).addClass(colors[randomNumber]);
};

//TAB FUNCTIONALITY
$(document).ready(
	$("body").on("click", ".tabs li", function() {
		var selectedIndex = ($(this).index());
		var wrapper = $(this).parents("div.subMain");
		var selectedContent = ($(wrapper).find(".content")[selectedIndex]);

		if($(this).siblings("li.active").hasClass('green')) {
			$(this).addClass('active green');
		} else if($(this).siblings("li.active").hasClass('blue')) {
			$(this).addClass('active blue');
		} else if($(this).siblings("li.active").hasClass('red')) {
			$(this).addClass('active red');
		} else {
			$(this).addClass('active');
		}

		$(this).siblings('.tabs li.active').removeClass('active');
		$(wrapper).find('.display').removeClass('display');
		$(selectedContent).addClass('display');
		return false;
	}),

	//DEFAULT TAB BOXES
	createTabBox(5, 2),
	createTabBox(3, 1),

	//FORM HANDLER
	$('form').on('submit', function(e) {
		e.preventDefault();
		createTabBox(numberTabs.value, defaultTab.value);
		this.reset();
		randomColor();
	})
	);