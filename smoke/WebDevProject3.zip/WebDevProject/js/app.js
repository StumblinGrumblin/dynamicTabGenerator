$(function() {
	$('.tabs li').click(function(){
		//$('.content').removeClass('display');
		$($(this).find('a').attr('href')).siblings(".content").removeClass('display');
		$(this).siblings('.tabs li.active').removeClass('active');
		$(this).addClass('active');
		$($(this).find('a').attr('href')).addClass('display');
		return false;
	});
	$('.left .tabs li:eq(1)').click();
	$('.right .tabs li:eq(0)').click();
});