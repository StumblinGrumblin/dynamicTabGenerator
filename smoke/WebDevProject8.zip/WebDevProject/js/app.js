//TAB FUNCTIONALITY
$("body").on("click", ".tabs li", function() {
	var selectedIndex = ($(this).index());
	var wrapper = $(this).parents("div.subMain");
	var selectedContent = ($(wrapper).find(".content")[selectedIndex]);

	$(this).siblings('.tabs li.active').removeClass('active');
	$(this).addClass('active');
	$(wrapper).find('.display').removeClass('display');
	$(selectedContent).addClass('display');
	return false;
});

//DYNAMIC TAB GENERATOR
var tabGenerator = function() {
	var tabs = $(".subMain:eq(0) .nav .tabs");
	var container = $(".subMain:eq(0) .container");
	var tabCount = $("li", tabs).length +1;

	$(tabs).append("<li class='dynamicTab'><a href='#'>Tab " + tabCount + "</a></li>");
	$(container).append("<div class='content'><h2>Content for Tab " + tabCount + "</h2>" + loremIpsum[tabCount] + "</div>");
}	;

//ELEMENT GENERATOR ON FORM SUBMIT
$('form').on('submit', function(e) {
	var formData = $(this).serializeArray();
	var tabCount = formData[0].value;
	var defaultTab = formData[1].value;
	
	e.preventDefault();
	$("#main").append("<div class='subMain'><div class='nav'><ul class='tabs clearfix'></ul></div><div class='container'></div></div>")
	
	for (var i=1; i <= tabCount; i++){
		$('.subMain:last ul.tabs').append("<li><a href='#'>Tab " + i + "</a></li>");
		$('.subMain:last div.container').append("<div class='content'><h2>Content for Tab " + i + "</h2>" + loremIpsum[i] + "</div>")
	};

	this.reset();
	if (defaultTab > 0 && defaultTab < tabCount) {
		$('.subMain:last .tabs li:eq(' + (defaultTab - 1) + ')').click();	
	} else {
		$('.subMain:last .tabs li:eq(0)').click();
	}
	
});

tabGenerator();

//DEFAULT SELECTORS
$('.subMain:eq(0) .tabs li:eq(1)').click();
$('.subMain:eq(1) .tabs li:eq(0)').click();




