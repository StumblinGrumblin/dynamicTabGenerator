// $(function() {
// 	var tabs = $(".subMain:eq(0) .nav .tabs");
// 	var container = $(".subMain:eq(0) .container");
// 	var tabCount = $("li", tabs).length +1;
// 	$(tabs).append("<li class='dynamicTab'><a href='#leftpanel" + tabCount + "'>Tab " + tabCount + "</a></li>");
// 	$(container).append("<div id='leftpanel" + tabCount + "' class='content'><h2>Content for Tab " + tabCount + "</h2><p>Bacon ipsum dolor sit amet kevin pork bacon ham hock salami jowl tri-tip drumstick ground round pastrami shoulder chicken tenderloin. Corned beef ham hock flank rump, pork loin doner pancetta brisket jerky beef ribs venison shankle biltong capicola andouille.</p><p>Drumstick tri-tip shankle cow, flank sausage biltong bresaola. Tongue shankle tail, ham prosciutto strip steak capicola biltong salami kielbasa ham hock hamburger turducken. T-bone pork loin ground round leberkas bresaola. Leberkas andouille filet mignon pig pancetta venison ham hock ham kevin ribeye doner biltong flank corned beef. Tongue hamburger corned beef brisket rump, salami sirloin pancetta swine kevin spare ribs meatball pork chop.</p><p>Andouille capicola fatback, pork beef ribs salami drumstick ribeye. Cow tail drumstick, short loin venison t-bone strip steak ham turducken sirloin tenderloin spare ribs kielbasa flank ribeye. T-bone short ribs pork belly hamburger fatback boudin pork loin ground round. T-bone rump filet mignon, kielbasa chicken bresaola short loin leberkas.</p><p>Bacon ipsum dolor sit amet kevin pork bacon ham hock salami jowl tri-tip drumstick ground round pastrami shoulder chicken tenderloin. Corned beef ham hock flank rump, pork loin doner pancetta brisket jerky beef ribs venison shankle biltong capicola andouille.</p></div>"
// 		);
	
// 	$('.tabs li').click(function(){
// 		//$('.content').removeClass('display');
// 		$($(this).find('a').attr('href')).siblings(".content").removeClass('display');
// 		$(this).siblings('.tabs li.active').removeClass('active');
// 		$(this).addClass('active');
// 		$($(this).find('a').attr('href')).addClass('display');
// 		return false;
// 	});
// 	$('.subMain:eq(0) .tabs li:eq(1)').click();
// 	$('.subMain:eq(1) .tabs li:eq(0)').click();
// });

$(".tabs li").on("click", function() {
	alert($(this).index());
});